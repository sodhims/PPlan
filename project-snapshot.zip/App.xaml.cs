﻿using System.Windows;

namespace ProjectPlanViewer
{
    public partial class App : Application
    {
    }
}